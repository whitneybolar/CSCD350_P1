package atcsim.loader.navaid;

public class LoaderAirway {

}
