package atcsim.loader.navaid;

import java.io.IOException;
import java.util.Map;
import java.util.Scanner;

import atcsim.datatype.Altitude;
import atcsim.datatype.CoordinateWorld3D;
import atcsim.datatype.Latitude;
import atcsim.datatype.Longitude;
import atcsim.datatype.UHFFrequency;
import atcsim.datatype.VHFFrequency;
import atcsim.graphics.view.navigation.OverlayNavigation;
import atcsim.loader.A_Loader;
import atcsim.world.navigation.A_ComponentNavaid;
import atcsim.world.navigation.ComponentNavaidFix;
import atcsim.world.navigation.ComponentNavaidNDB;

// Loads the definition of zero or more nondirectional beacon (NDB) navaids, 
// creates the corresponding navaids, and adds them to the given navigation overlay.
public class LoaderNDB extends A_Loader {
	// Creates an NDB loader.
	// Parameters:
	// navaids - - the shared collection of navaids
    // overlay - - the navigation overlay that holds the navaids to be loaded
	  public LoaderNDB(Map<String, A_ComponentNavaid<?>> navaids, OverlayNavigation overlay) {
		  super(navaids, overlay);
		  System.out.println("LoaderNDB constructor!");
	  }
	  
	  // Loads the NDB section of the definition into the overlay.
	  // Parameters:
	  // scanner - - the scanner for the definition
	  // Throws:
	  // java.io.IOException - for any file error
		  public void load(Scanner scanner) throws IOException {
			  System.out.println("LoaderFix load!");
			  boolean sectionFound = false;
			  while(scanner.hasNextLine()) {
				  String line = scanner.nextLine();
		    	  if (line.isEmpty())
					  sectionFound = false;
				  
		          if (sectionFound) {
		        	  ComponentNavaidNDB fix = null;
		        	  
		        	  System.out.println("Process values of NavaidNDB: " + line);
		        	  String[] values = line.split(" ");
		        	  
		        	  // grab categorize each element from the line 
		        	  String id = parseId(values[0]); 
		        	  UHFFrequency freq = parseUHFFrequency(values[1]);
	            	  Latitude latitude = parseLatitude(values[2]);
	            	  Longitude longitude = parseLongitude(values[3]);
	            	  Altitude altitude = parseAltitude(values[4]);
	            	  fix = new ComponentNavaidNDB(id, new CoordinateWorld3D(latitude, longitude, altitude), freq);
		        		  
		        	  System.out.println("Process ComponentNavaidNDB: " + fix);

		        	  // Add to the map so we can use it later to search by id
		        	  if (!navaids.containsKey(id) && fix != null)
		        	  {
		        		  navaids.put(id, fix);
		        		  overlay.addNavaid(fix);
		        	  }
		          }
				  
				  if (line.equals("[NAVAID:NDB]"))
					  sectionFound = true;
		    	
			  }
			  scanner.close();
	  }

}