package atcsim.loader.navaid;

public class LoaderNDB {

}
