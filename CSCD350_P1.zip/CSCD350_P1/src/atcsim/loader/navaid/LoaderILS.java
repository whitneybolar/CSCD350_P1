package atcsim.loader.navaid;

import java.io.IOException;
import java.util.Map;
import java.util.Scanner;
import java.util.*;

import atcsim.datatype.*;
import atcsim.graphics.view.navigation.OverlayNavigation;
import atcsim.loader.A_Loader;
import atcsim.world.navigation.A_ComponentNavaid;
import atcsim.world.navigation.ComponentNavaidILS;
import atcsim.world.navigation.NavaidILSBeaconDescriptor;

// Loads the definition of zero or more instrument landing system (ILS) navaids, 
// creates the corresponding navaids, and adds them to the given navigation overlay.
public class LoaderILS extends A_Loader {
	// Creates an ILS loader.
	// Parameters:
	// navaids - - the shared collection of navaids
	// overlay - - the navigation overlay that holds the navaids to be loaded
	public LoaderILS(Map<String, A_ComponentNavaid<?>> navaids, OverlayNavigation overlay) {
		super(navaids, overlay);
		System.out.println("LoaderILS constructor!");
	}

	// Loads the ILS section of the definition into the overlay.
	// Parameters:
	// scanner - - the scanner for the definition
	// Throws:
	// java.io.IOException - for any file error
	public void load(Scanner scanner) throws IOException {
		System.out.println("LoaderILS load!");
		boolean dataPresent = false;
		while (scanner.hasNextLine()) {
			String line = scanner.nextLine();
			if (line.isEmpty())
				dataPresent = false;

			if (dataPresent) {
				ComponentNavaidILS ils = null;

				System.out.println("Process values of NavaidILS: " + line);
				String[] values = line.split(" ");

				String id = parseId(values[0]);
				VHFFrequency frequency = parseVHFFrequency(values[1]);
				Latitude latitude = parseLatitude(values[2]);
				Longitude longitude = parseLongitude(values[3]);
				Altitude altitude = parseAltitude(values[4]);
				
				CoordinateWorld3D position = new CoordinateWorld3D(latitude, longitude, altitude);
				
				AngleNavigational azimuth = parseCompass(values[5]);

				//creating the outer ILS Beacon
				String[] beaconOuter = values[6].split(",");
				Distance distanceOuter = new Distance(Double.parseDouble(beaconOuter[0]));
				Altitude altitudeOuter = new Altitude(Double.parseDouble(beaconOuter[1]));
				NavaidILSBeaconDescriptor markerOuter = new NavaidILSBeaconDescriptor(distanceOuter, altitudeOuter);

				//creating the middle ILS Beacon
				String[] beaconMiddle = values[7].split(",");
				Distance distanceMiddle = new Distance(Double.parseDouble(beaconMiddle[0]));
				Altitude altitudeMiddle = new Altitude(Double.parseDouble(beaconMiddle[1]));
				NavaidILSBeaconDescriptor markerMiddle = new NavaidILSBeaconDescriptor(distanceMiddle, altitudeMiddle);

				//Creating the inner ILS Beacon
				String[] beaconInner = values[8].split(",");
				Distance distanceInner = new Distance(Double.parseDouble(beaconInner[0]));
				Altitude altitudeInner = new Altitude(Double.parseDouble(beaconInner[1]));
				NavaidILSBeaconDescriptor markerInner = new NavaidILSBeaconDescriptor(distanceInner, altitudeInner);

				ils = new ComponentNavaidILS(id, position, azimuth, frequency, markerOuter, markerMiddle, markerInner);

				System.out.println("Process ComponentNavaidILS: " + ils);

				// Add to the map so we can use it later to search by id
				if (!navaids.containsKey(id) && ils != null) {
					navaids.put(id, ils);
					overlay.addNavaid(ils);
				}
			}

			if (line.equals("[NAVAID:ILS]"))
				dataPresent = true;

		}
		scanner.close();

	}

	protected AngleNavigational parseCompass(String input) {
		return new AngleNavigational(Double.parseDouble(input.split(",")[0]));
	}

}
