package atcsim.loader.navaid;

import java.io.IOException;
import java.util.Map;
import java.util.Scanner;

import atcsim.datatype.Altitude;
import atcsim.datatype.CoordinateWorld3D;
import atcsim.datatype.Latitude;
import atcsim.datatype.Longitude;
import atcsim.datatype.VHFFrequency;
import atcsim.graphics.view.navigation.OverlayNavigation;
import atcsim.loader.A_Loader;
import atcsim.world.navigation.A_ComponentNavaid;
import atcsim.world.navigation.ComponentNavaidFix;
import atcsim.world.navigation.ComponentNavaidVOR;

// Loads the definition of zero or more fix navaids, 
// creates the corresponding navaids, and adds them to the given navigation overlay.
public class LoaderFix extends A_Loader {
	
	// Creates a fix loader.
	// Parameters:
	// navaids - - the shared collection of navaids
	// overlay - - the navigation overlay that holds the navaids to be loaded
	  public LoaderFix(Map<String, A_ComponentNavaid<?>> navaids, OverlayNavigation overlay) {
		  super(navaids, overlay);
		  System.out.println("LoaderFix constructor!");
	  }
	  
	  // Loads the fix section of the definition into the overlay.
	  // Parameters:
      // scanner - - the scanner for the definition
	  // Throws:
	  // java.io.IOException - for any file error
	  public void load(Scanner scanner) throws IOException {
		  System.out.println("LoaderFix load!");
		  boolean sectionFound = false;
		  while(scanner.hasNextLine()) {
			  String line = scanner.nextLine();
	    	  if (line.isEmpty())
				  sectionFound = false;
			  
	          if (sectionFound) {
	        	  ComponentNavaidFix fix = null;
	        	  
	        	  System.out.println("Process values of NavaidFix: " + line);
	        	  String[] values = line.split(" ");
	        	  
	        	  // grab categorize each element from the line 
	        	  String id = parseId(values[0]); 
            	  Latitude latitude = parseLatitude(values[1]);
            	  Longitude longitude = parseLongitude(values[2]);
            	  Altitude altitude = parseAltitude(values[3]);
            	  fix = new ComponentNavaidFix(id, new CoordinateWorld3D(latitude, longitude, altitude));
	        		  
	        	  System.out.println("Process ComponentNavaidFix: " + fix);

	        	  // Add to the map so we can use it later to search by id
	        	  if (!navaids.containsKey(id) && fix != null)
	        	  {
	        		  navaids.put(id, fix);
	        		  overlay.addNavaid(fix);
	        	  }
	          }
			  
			  if (line.equals("[NAVAID:FIX]"))
				  sectionFound = true;
	    	
		  }
		  scanner.close();
	  }
}
