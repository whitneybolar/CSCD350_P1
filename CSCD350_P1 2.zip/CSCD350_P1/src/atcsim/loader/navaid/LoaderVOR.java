package atcsim.loader.navaid;

public class LoaderVOR {

}
