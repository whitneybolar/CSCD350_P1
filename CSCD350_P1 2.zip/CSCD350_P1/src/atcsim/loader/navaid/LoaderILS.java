package atcsim.loader.navaid;

public class LoaderILS {

}
